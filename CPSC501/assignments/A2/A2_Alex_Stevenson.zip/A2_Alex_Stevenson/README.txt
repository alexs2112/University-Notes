GitHub Code Repository: https://github.com/alexs2112/CPSC501-ObjectInspector

This project utilizes java packages to better organize the code. Inspector specific code is within the `inspector` directory, while unit test related code is within the `unit_tests` and `test_classes` directory. All three of these directories must be compiled to run.

```
javac inspector/*.java
javac test_classes/*.java
javac unit_tests/*.java
```

`inspector/Inspector.java` is the main Inspector class, the other classes within this package are helper classes to better organize the data output from the inspect method.

Unit tests can be run individually or with the `TestAll` class. This can be run from the project root directory with:
`java org.junit.runner.JUnitCore unit_tests.TestAll`

The version control logs can be found in three places:
 - `git_log.txt`: This lists the output from `git log`
 - `git_log_full.txt`: This lists the full output from `git log -p`
 - The repository commit history. This can be found here: https://github.com/alexs2112/CPSC501-ObjectInspector/commits/master. Clicking on individual commits will show the diff in a far more human-readable way.
