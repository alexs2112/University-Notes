package test_classes;

public class HashClass {
    public HashClass(Object a, Object b) {
        this.A = a;
        this.B = b;
    }
    public Object A;
    public Object B;
}
