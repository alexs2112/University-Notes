package test_classes;

public interface DefaultInterface {
    public void methodOne();
    public String methodTwo(int a);
}
