package test_classes;

public class BaseClass {
    public int superPublic = 4;
    protected int superProtected = 5;
    private int superPrivate = 6;
}
