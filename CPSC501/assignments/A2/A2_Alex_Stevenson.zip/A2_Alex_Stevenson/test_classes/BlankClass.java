package test_classes;

public class BlankClass { }
