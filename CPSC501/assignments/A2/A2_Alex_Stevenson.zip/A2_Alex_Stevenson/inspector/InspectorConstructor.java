package inspector;

public class InspectorConstructor {
    public String[] parameters;
    public String modifiers;
}
