package inspector;

public class InspectorMethod {
    public String name;
    public String[] exceptions;
    public String[] parameters;
    public String returnType;
    public String modifiers;
}
