void fft_convolution(float *x, int N, float *h, int M, float *y, int P);
void *complex_multiply(void *v);
void zero_padding(float *signal, int input_size, float *output, int output_size);
