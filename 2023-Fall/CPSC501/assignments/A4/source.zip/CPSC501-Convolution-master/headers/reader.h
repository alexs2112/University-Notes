#ifndef FILE_STRUCTS_H
#define FILE_STRUCTS_H
#include "./file_structs.h"
#endif

wav_file read_file(char* filename);
