void linear_convolution(float* x, int N, float* h, int M, float* y, int P);
