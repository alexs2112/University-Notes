#ifndef FILE_STRUCTS_H
#define FILE_STRUCTS_H
#include "./file_structs.h"
#endif

void write_to_file(wav_file wav, char* filename);
