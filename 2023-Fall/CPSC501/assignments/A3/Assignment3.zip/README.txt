Source code located in `CPSC501-Serializer.zip`

Unit tests also present in the compressed file, in the `unit_tests` directory. For ease of use, these can be run with the `test.bat` batch script.

Version control logs in `gitlog.txt` and `gitlog_full.txt`

Refactorings located in `refactorings.md`
